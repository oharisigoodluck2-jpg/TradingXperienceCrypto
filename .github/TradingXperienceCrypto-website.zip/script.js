const prices={"BTC/USD":"$67,420","EUR/USD":"1.1642","XAU/USD":"$3,338"};
let balance=10000;
function selectMarket(m){document.getElementById("marketSelect").value=m;updateTerminal();document.getElementById("terminal").scrollIntoView({behavior:"smooth"});}
function updateTerminal(){const m=document.getElementById("marketSelect").value;document.getElementById("terminalMarket").textContent=m;document.getElementById("terminalValue").textContent=prices[m];document.getElementById("result").textContent=`${m} selected. This is a simulated market view for educational practice only.`;}
function simulateTrade(side){const m=document.getElementById("marketSelect").value;const change=(Math.random()*80-40).toFixed(2);balance+=Number(change);document.getElementById("balance").textContent="$"+balance.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});document.getElementById("result").textContent=`Simulated ${side} decision on ${m}. Hypothetical result: ${change>=0?"+":""}$${change}. No real order was placed.`;}
function resetDemo(){balance=10000;document.getElementById("balance").textContent="$10,000.00";document.getElementById("result").textContent="Demo portfolio reset. Choose a market and practice another simulated decision.";}
updateTerminal();
