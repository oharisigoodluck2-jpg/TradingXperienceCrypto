TradingXperienceCrypto
======================
Educational Bitcoin & Forex demo website.

Files:
- index.html
- styles.css
- script.js

How to use:
1. Keep all three files in the same folder.
2. Open index.html in a browser.
3. For online hosting, upload the folder to a static website host.

The demo terminal is simulated and does not process real-money deposits, withdrawals, or trades.
